This allows to hide field by pressing the "p" key on the keyboard
