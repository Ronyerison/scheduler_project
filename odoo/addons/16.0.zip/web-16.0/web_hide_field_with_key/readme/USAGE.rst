Add the class web-hide-field to a field:

::

   <field name="name" class="web-hide-field">

Then press the "p" key and the field will disappear
