* Petar Najman <petar.najman@modoolar.com>
* Mladen Meseldzija <mladen.meseldzija@modoolar.com>
* `CorporateHub <https://corporatehub.eu/>`__

  * Alexey Pelykh <alexey.pelykh@corphub.eu>

* Manuel Calero - Tecnativa
* Matias Peralta, Juan Rivero - Adhoc
