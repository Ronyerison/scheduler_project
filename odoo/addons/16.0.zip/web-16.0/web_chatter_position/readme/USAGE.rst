#. There's a **Chatter Position** option in **User Preferences**, where you can
choose between ``auto``, ``bottom`` and ``sided``.
#. The position can also be changed on the fly using a new button on the top right side of Form Views.
