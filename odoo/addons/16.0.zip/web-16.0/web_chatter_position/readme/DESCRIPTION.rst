Configurable chatter position from the user preferences.
Change Chatter Position on the fly.
Supports Both Community & Enterprise Edition.
