* Go to `Settings` > `Technical` > `User Interface` > `Web editor Class`.
* Create and name your custom CSS classes.
* Go to any model with an HTML field (e.g., `Settings` > `Users` > `Preferences` > `Signature`).
* In the HTML editor, select any content block.
* Choose from the available CSS classes to apply the desired styling.
