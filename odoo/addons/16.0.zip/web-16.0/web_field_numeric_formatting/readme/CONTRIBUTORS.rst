* Lucas Perais (lpe) <lpe@odoo.com> contributed the original code to Odoo.
* Stefan Rijnhart <stefan@opener.amsterdam> created the backport to Odoo 16
  in this module.
