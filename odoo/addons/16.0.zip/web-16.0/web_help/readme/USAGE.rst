**Demo:**

  .. image:: ../static/description/demo.gif

You can see the demo live by going to the users list view (Settings > Users & Companies > Users)
and clicking the little '?' next to the view switcher.

  .. image:: ../static/description/viewswitcher.png

Also there's a demo for the change password wizard:

  .. image:: ../static/description/changepassword.png

It's easy to create your own guides, please refer to ``static/src/user_trip.esm.js`` and
``static/src/change_password_trip.esm.js``
