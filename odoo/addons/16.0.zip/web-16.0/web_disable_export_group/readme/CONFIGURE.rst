Enable the group *Direct Export* to the users who are allowed to make use of the option
'Export xlsx' from the list view.
