- Users in the *Access to export feature* group or admins can export in any way.
- Users in the *Direct Export (xlsx)* group can only use the default export feature
  from the list view.
