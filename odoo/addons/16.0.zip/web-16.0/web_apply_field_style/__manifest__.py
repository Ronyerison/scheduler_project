{
    "name": "Apply Field Style",
    "author": "Akretion,Odoo Community Association (OCA)",
    "summary": "Apply css class style to fields from a dict parameters",
    "version": "16.0.1.0.1",
    "license": "AGPL-3",
    "maintainer": ["bealdav"],
    "website": "https://github.com/OCA/web",
    "category": "web",
    "depends": [
        "base",
    ],
    "data": [],
    "installable": True,
}
