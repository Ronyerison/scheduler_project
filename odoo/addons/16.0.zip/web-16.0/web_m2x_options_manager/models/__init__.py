# Copyright 2021 Camptocamp SA
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

from . import ir_model
from . import ir_ui_view
from . import m2x_create_edit_option
