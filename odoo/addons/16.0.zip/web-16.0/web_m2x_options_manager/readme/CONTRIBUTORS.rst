* `Camptocamp <https://www.camptocamp.com>`__:

  * Silvio Gregorini
* Duong (Tran Quoc) <duongtq@trobz.com>
