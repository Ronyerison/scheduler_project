Go to Settings > Technical > Models.

Choose the model you wish to edit, and open its form view. Go to the
"Create/Edit Options" tab, and add the fields you want to manage.

Button "Fill" will add every missing field to the options.
Button "Empty" will remove every option.
