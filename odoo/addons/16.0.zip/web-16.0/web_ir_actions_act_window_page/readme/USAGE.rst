See the 'Previous Partner' and 'Next Partner' buttons that this module's demo data adds
to the partner form view.
