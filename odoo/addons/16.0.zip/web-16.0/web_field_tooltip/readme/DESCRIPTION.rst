This module gives the possibility to add tooltips next to fields labels on any
field of a model. The tooltip displays an html field.
