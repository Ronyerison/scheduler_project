* Find a way to update form views after tooltips update without refreshing manually
