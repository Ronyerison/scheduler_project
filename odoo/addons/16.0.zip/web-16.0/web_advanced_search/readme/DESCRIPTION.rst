More powerful and easy to use search, especially for related fields.
