This module removes from the web interface the bubbles introduced in the version 10.0.
The help boxes are not removed though.
