* David Dufresne (david.dufresne@savoirfairelinux.com)
* Alexandre Díaz (alexandre.diaz@tecnativa.com)
* Elliott Bristow - Glodo (elliott@glo.systems)
* Thanakrit Pintana (thanakrit.p39@gmail.com)
